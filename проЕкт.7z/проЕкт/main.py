import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QRadioButton, QVBoxLayout, QPushButton
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import QByteArray
from PyQt5 import uic
from queries import Selec_Prod
from connection import connection_to_db

class MainWindows(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("untitled.ui", self)
        self.setup_ui()

    def setup_ui(self):
        data = Selec_Prod()
        layout = QVBoxLayout(self)
        if data:
            h = 80
            for i in data:
                img = i[2]
                gimg = QImage.fromData(QByteArray(img))
                pixmap = QPixmap.fromImage(gimg)
                f_p = f'{i[0]}.jpg'
                pixmap.save(f_p, "JPG")
                lb_rad = QRadioButton(f"{i[1]}", self)
                lb_rad.setObjectName(f"{i[0]}")

                lb_rad.setStyleSheet(f"QRadioButton::indicator {{width: 60px; height: 60px;}}"
                                     f"QRadioButton::indicator::unchecked"
                                     f"{{image:url('{i[0]}.jpg');}}"
                                     f"QRadioButton::indicator::checked"
                                     f"{{image:url('gal.png');}}")
                layout.addWidget(lb_rad)
                lb_rad.setGeometry(40,  h, 100, 100)
                h += 100
                layout.addWidget(lb_rad)
                lb_rad.toggled.connect(self.on_toggled)

            bt = QPushButton('Проголосовать', self)
            layout.addWidget(bt)
            bt.clicked.connect(self.on_click)

    def on_toggled(self, checked):
        radio = self.sender()
        if checked:
            self.selected_radio = radio

    def on_click(self):
        if hasattr(self, 'selected_radio'):
            film_id = int(self.selected_radio.objectName())
            cursor = connection_to_db().cursor()
            cursor.execute(f"UPDATE cinema SET rating = rating + 1 WHERE id = {film_id}")
            connection_to_db().commit()
            print('Голос учтен для фильма с ID:', film_id)
        else:
            print('Фильм не выбран')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = MainWindows()
    form.show()
    sys.exit(app.exec_())
