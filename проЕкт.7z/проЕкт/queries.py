from connection import connection_to_db

def Selec_Prod():
    conn = connection_to_db()
    cursor = conn.cursor()

    query = "SELECT * FROM cinema;"
    cursor.execute(query)

    rows = cursor.fetchall()

    cursor.close()
    conn.close()

    return rows


def Select_Image_From_DB():
    conn = connection_to_db()
    cursor = conn.cursor()

    query = "SELECT img FROM cinema"
    cursor.execute(query)

    images = cursor.fetchall()

    cursor.close()
    conn.close()

    return images

