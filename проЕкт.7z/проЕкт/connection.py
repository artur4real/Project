import pymysql

def connection_to_db():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="root",
        database="b3"
    )
